# LifeLine AI

Emergency + Help Finder Platform

## Features
- SOS Button
- Simple UI
